import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:money_tracker/controllers/transaction_controller.dart';

class AddTransactionPage extends StatelessWidget {
  final TransactionController transactionController =
      Get.put(TransactionController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Transaction")),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            // Amount Input
            TextField(
              controller: transactionController.amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Amount"),
            ),

            // Description Input
            TextField(
              controller: transactionController.descriptionController,
              decoration: InputDecoration(labelText: "Description"),
            ),

            // Transaction Type (Income/Expense)
            Obx(
              () => DropdownButton<String>(
                value: transactionController.selectedType.value,
                items: transactionController.types.map((String type) {
                  return DropdownMenuItem(
                    value: type,
                    child: Text(type.capitalizeFirst!),
                  );
                }).toList(),
                onChanged: (value) {
                  transactionController.selectedType.value = value!;
                  // Reset category when type changes
                  transactionController.selectedCategory.value =
                      transactionController.categories[value]?.first ?? "";
                },
                hint: Text("Select Type"),
              ),
            ),

            // Category Dropdown (Dynamic based on type)
            Obx(
              () => DropdownButton<String>(
                value: transactionController.selectedCategory.value,
                items: transactionController
                        .categories[transactionController.selectedType.value]
                        ?.map((String category) {
                      return DropdownMenuItem(
                        value: category,
                        child: Text(category),
                      );
                    }).toList() ??
                    [],
                onChanged: (value) =>
                    transactionController.selectedCategory.value = value!,
                hint: Text("Select Category"),
              ),
            ),

            // Submit Button
            ElevatedButton(
              onPressed: transactionController.addTransaction,
              child: Text("Add"),
            ),
          ],
        ),
      ),
    );
  }
}
