import 'package:hive/hive.dart';

part 'transaction_model.g.dart';

@HiveType(typeId: 0)
class TransactionModel {
  @HiveField(0)
  final String id;
  @HiveField(1)
  final String type; // 'income' or 'expense'
  @HiveField(2)
  final String category;
  @HiveField(3)
  final double amount; // positive for income, negative for expense
  @HiveField(4)
  final DateTime date;
  @HiveField(5)
  final String description;

  TransactionModel({
    required this.id,
    required this.type,
    required this.category,
    required this.amount,
    required this.date,
    required this.description,
  });
}
