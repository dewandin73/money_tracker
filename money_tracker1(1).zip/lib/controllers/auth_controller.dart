import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../views/home/home_page.dart';

class AuthController extends GetxController {
  // Controllers
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController retypePasswordController = TextEditingController();

  // Login method
  void login() {
    if (emailController.text.isNotEmpty && passwordController.text.isNotEmpty) {
      FocusScope.of(Get.context!).unfocus();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Get.offAll(() => HomePage());
      });
    } else {
      Get.snackbar("Login Failed", "Please enter email and password",
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  // Register method
  void register() {
    if (passwordController.text != retypePasswordController.text) {
      Get.snackbar("Error", "Passwords do not match",
          snackPosition: SnackPosition.BOTTOM);
      return;
    }
    print(
        "User Registered: ${firstNameController.text} ${lastNameController.text}");
    Get.back();
  }

  // Improved logout method
  void logout() {
    try {
      // Clear controllers
      firstNameController.clear();
      lastNameController.clear();
      emailController.clear();
      passwordController.clear();
      retypePasswordController.clear();

      // Close overlays
      if (Get.isSnackbarOpen) Get.closeAllSnackbars();
      if (Get.isDialogOpen == true) Get.back();

      // Navigate
      Get.offAllNamed('/login');

      // Feedback
      Future.delayed(const Duration(milliseconds: 300), () {
        Get.snackbar("Logged Out", "Successfully logged out",
            snackPosition: SnackPosition.BOTTOM);
      });
    } catch (e) {
      Get.snackbar("Logout Error", e.toString(),
          snackPosition: SnackPosition.BOTTOM);
    }
  }
}
