import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import '../data/models/transaction_model.dart';
import '../data/hive_boxes.dart';

class TransactionController extends GetxController {
  var transactions = <TransactionModel>[].obs;

  // Input controllers
  TextEditingController amountController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  // Selection observables
  var selectedType = "expense".obs; // Default to expense
  var selectedCategory = "Food".obs;

  // Available options
  var types = ["income", "expense"].obs;
  var categories = {
    "income": ["Salary", "Bonus", "Freelance", "Other Income"],
    "expense": ["Food", "Travel", "Bills", "Shopping", "Other"]
  }.obs;

  @override
  void onInit() {
    super.onInit();
    loadTransactions();
  }

  void loadTransactions() async {
    if (!Hive.isBoxOpen('transactions')) {
      await Hive.openBox<TransactionModel>('transactions');
    }
    transactions.assignAll(HiveBoxes.getTransactions().values.toList());
  }

  void addTransaction() {
    // Validate amount
    final amount = double.tryParse(amountController.text) ?? 0.0;
    if (amount <= 0) {
      Get.snackbar("Error", "Enter a valid amount",
          snackPosition: SnackPosition.BOTTOM);
      return;
    }

    // Create transaction
    final transaction = TransactionModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      type: selectedType.value,
      category: selectedCategory.value,
      amount: selectedType.value == "expense" ? -amount.abs() : amount.abs(),
      date: DateTime.now(),
      description: descriptionController.text,
    );

    // Save to Hive
    var box = HiveBoxes.getTransactions();
    box.put(transaction.id, transaction);
    transactions.add(transaction);
    transactions.refresh();

    // Clear inputs
    amountController.clear();
    descriptionController.clear();

    // Navigate back and show success
    Get.back();
    Get.snackbar("Success", "Transaction added",
        snackPosition: SnackPosition.BOTTOM);
  }

  void deleteTransaction(String id) {
    var box = HiveBoxes.getTransactions();
    box.delete(id);
    transactions.removeWhere((t) => t.id == id);
    transactions.refresh();
  }

  // Helper to get categories for current selected type
  List<String> getCurrentCategories() {
    return categories[selectedType.value] ?? [];
  }
}
